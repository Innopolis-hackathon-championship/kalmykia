import sqlite3

import segno
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from Config import token, pay_token
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.types import LabeledPrice, Message, PreCheckoutQuery, ContentType, ShippingQuery, ShippingOption
from random import randint


def random_id():
    return randint(1, 10000000000)


class Form(StatesGroup):
    name = State()
    cl = State()
    liter = State()
    snils = State()
    email = State()


class Count(StatesGroup):
    index_name = State()
    count = State()


class Review(StatesGroup):
    star = State()
    rev = State()


storage = MemoryStorage()
bot = Bot(token=token)
dp = Dispatcher(bot, storage=storage)


fast_shipping_option = ShippingOption(id='fast', title='Быстрая').add(LabeledPrice('Быстрая', 50000))


@dp.callback_query_handler(lambda c: c.data == 'buy')
async def buy_process(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    datas = cur.execute(f"SELECT * FROM cart WHERE user_id='" + f'{callback_query.from_user.id}' + "';").fetchall()
    conn.commit()
    sl = dict()
    for i in datas:
        if i[1] in sl:
            sl[i[1]] += int(i[2])
        else:
            sl[i[1]] = int(i[2])
    new = dict()
    for i in sl:
        req = f"SELECT * FROM products WHERE product_id='" + f'{i}' + "';"
        product_info = cur.execute(req).fetchall()
        new[product_info[0][2]] = ((sl[i] * product_info[0][4]) / 100, sl[i], product_info[0][4])
    cur.execute(f"DELETE FROM cart WHERE user_id = '{callback_query.from_user.id}';")
    conn.commit()
    text = ''
    itogo = 0
    for i in new:
        text += f'{i} - {new[i][-1] / 100}/шт - {new[i][1]}шт - {new[i][-1] / 100 * new[i][1]}р\n'
        itogo += new[i][-1] * new[i][1]

    order = LabeledPrice(label='Заказ', amount=itogo)
    await bot.send_invoice(callback_query.from_user.id,
                           title='Заказ',
                           description='Заказ из вашего любимого буфета',
                           provider_token=pay_token,
                           currency='rub',
                           need_email=True,
                           is_flexible=True,
                           prices=[order],
                           start_parameter='example',
                           payload='some_invoice')


@dp.shipping_query_handler(lambda query: True)
async def shipping_process(shipping_query: ShippingQuery):
    if shipping_query.shipping_address.country_code == 'MG':
        return await bot.answer_shipping_query(
            shipping_query.id,
            ok=False,
            error_message='Сюда не доставляем!'
        )
    shipping_options = [ShippingOption(id='regular',
                                       title='Самовывоз').add(LabeledPrice('Обычная доставка', 0))]

    if shipping_query.shipping_address.country_code == 'RU':
        shipping_options.append(fast_shipping_option)

    await bot.answer_shipping_query(
        shipping_query.id,
        ok=True,
        shipping_options=shipping_options
    )


@dp.pre_checkout_query_handler(lambda query: True)
async def pre_checkout_process(pre_checkout: PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout.id, ok=True)

@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def successful_payment(message: Message):
    await bot.send_message(message.chat.id, 'Платеж прошел успешно!')
    a = random_id()
    cur.execute('''INSERT INTO queue VALUES(?, ?)''', [int(message.from_user.id), a])
    conn.commit()
    segno.make_qr(f'{message.from_user.id} {a}').save('1.png')
    p = open('1.png', 'rb')
    await bot.send_photo(message.chat.id, p, reply_markup=inline_kb_menu)


inline_btn_drinks = InlineKeyboardButton('🍹 Напитки 🍹', callback_data='drinks')
inline_btn_bakery = InlineKeyboardButton('🥐 Выпечка 🥐', callback_data='bakery')
inline_btn_back = InlineKeyboardButton('🔙Назад', callback_data="back")
inline_btn_back_to_drink = InlineKeyboardButton('🔙Назад к напиткам', callback_data="back_to_drink")
inline_btn_back_to_bakery = InlineKeyboardButton('🔙Назад к выпечке', callback_data="back_to_bakery")
inline_btn_cartadd = InlineKeyboardButton('➕В Корзину🛒', callback_data='cartadd')
inline_btn_go_cart = InlineKeyboardButton('Переход в корзину🛒.', callback_data='go_cart')
inline_kb_menu = (InlineKeyboardMarkup().add(inline_btn_drinks).add(inline_btn_bakery).add(inline_btn_go_cart).
                  add(InlineKeyboardButton('Оставить отзыв.', callback_data='review')))
inline_kb_drinks = InlineKeyboardMarkup()
inline_kb_bakery = InlineKeyboardMarkup()
inline_kb_product = InlineKeyboardMarkup().insert(inline_btn_cartadd).add(inline_btn_drinks).add(inline_btn_bakery).add(inline_btn_back_to_drink)

inline_kb_product_drink = InlineKeyboardMarkup().insert(inline_btn_cartadd).add(inline_btn_back_to_drink)
inline_kb_product_drink_and_soldout = InlineKeyboardMarkup().add(inline_btn_back_to_drink)
inline_kb_product_bakery = InlineKeyboardMarkup().insert(inline_btn_cartadd).add(inline_btn_back_to_bakery)
inline_kb_product_bakery_and_soldout = InlineKeyboardMarkup().add(inline_btn_back_to_bakery)

inline_btn_buy = InlineKeyboardButton('Оплатить.', callback_data='buy')
inline_btn_cart_pop = InlineKeyboardButton('Убрать позиции.', callback_data='cart_pop')

inline_kb_cart = (InlineKeyboardMarkup().add(inline_btn_buy).add(inline_btn_cart_pop).add(inline_btn_back))


conn = sqlite3.connect('dishes_menu.db')
cur = conn.cursor()
cur.execute("SELECT * FROM products;")
for i in cur.fetchall():
    btn = InlineKeyboardButton(i[2], callback_data=f'output_{i[0]}')
    if i[7] == 'drinks':
        inline_kb_drinks.add(btn)
    else:
        inline_kb_bakery.add(btn)
inline_kb_drinks.add(inline_btn_back)
inline_kb_bakery.add(inline_btn_back)


@dp.callback_query_handler(lambda c: 'cart_pop' == c.data)
async def process_cart_pop(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    cur.execute(f"DELETE FROM cart WHERE user_id = '{callback_query.from_user.id}';")
    conn.commit()
    await callback_query.message.reply('Корзина очищена.', reply_markup=inline_kb_menu)


@dp.callback_query_handler(lambda c: c.data == 'bakery')
async def process_callback_bakery(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, 'Выпечка', reply_markup=inline_kb_bakery)


@dp.callback_query_handler(lambda c: c.data == 'drinks')
async def process_callback_drinks(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, 'Напитки', reply_markup=inline_kb_drinks)


@dp.callback_query_handler(lambda c: c.data == 'back')
async def process_callback_bakery(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, 'Нажимай на категорию', reply_markup=inline_kb_menu)


@dp.callback_query_handler(lambda c: c.data == 'back_to_drink')
async def process_callback_back_to_drink(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, 'Нажимай на напиток', reply_markup=inline_kb_drinks)


@dp.callback_query_handler(lambda c: c.data == 'back_to_bakery')
async def process_callback_back_to_bakery(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.from_user.id)
    await bot.send_message(callback_query.from_user.id, 'Нажимай на выпечку', reply_markup=inline_kb_bakery)


@dp.callback_query_handler(lambda c: c.data == 'go_cart')
async def process_show_cart(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)

    datas = cur.execute(f"SELECT * FROM cart WHERE user_id='" + f'{callback_query.from_user.id}' + "';").fetchall()
    conn.commit()
    sl = dict()
    for i in datas:
        if i[1] in sl:
            sl[i[1]] += int(i[2])
        else:
            sl[i[1]] = int(i[2])
    new = dict()
    for i in sl:
        req = f"SELECT * FROM products WHERE product_id='" + f'{i}' + "';"
        product_info = cur.execute(req).fetchall()

        new[product_info[0][2]] = ((sl[i] * product_info[0][4]) / 100, sl[i], product_info[0][4])
    text = ''
    itogo = 0
    for i in new:
        text += f'{i} - {new[i][-1]/100}/шт - {new[i][1]}шт - {new[i][-1]/100 * new[i][1]}р\n'
        itogo += new[i][-1]/100 * new[i][1]

    text += f'Итого:{str(itogo)}р'
    if itogo == 0:
        keyboard = InlineKeyboardMarkup().add(inline_btn_back)
    else:
        keyboard = InlineKeyboardMarkup().add(inline_btn_buy).add(inline_btn_cart_pop).add(inline_btn_back)
    await bot.send_message(callback_query.from_user.id, text, reply_markup=keyboard)
    await bot.send_message(callback_query.from_user.id, text, reply_markup=inline_kb_cart)


x = []
@dp.callback_query_handler(lambda c: any(['output' in c.data, x.append(c.data)]))
async def process_callback_card(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    indx = int(x[-1].split('_')[-1])
    x.clear()
    cur.execute("SELECT * FROM products;")
    product = cur.fetchall()[indx]
    category = product[7]
    if product[3] == 0:
        cnt = 'НЕТУ В НАЛИЧИИ!'
    else:
        cnt = f'В наличии: {product[3]}'
    keyboard = None
    if category == 'bakery' and cnt == 'НЕТУ В НАЛИЧИИ!':
        keyboard = inline_kb_product_bakery_and_soldout
    elif category == 'bakery' and cnt != 'НЕТУ В НАЛИЧИИ!':
        keyboard = inline_kb_product_bakery
    elif category == 'drinks' and cnt == 'НЕТУ В НАЛИЧИИ!':
        keyboard = inline_kb_product_drink_and_soldout
    elif category == 'drinks' and cnt != 'НЕТУ В НАЛИЧИИ!':
        keyboard = inline_kb_product_drink
    await bot.send_photo(callback_query.from_user.id, open(f'./image/{product[6]}', 'rb'))
    await bot.send_message(callback_query.from_user.id, f'{product[2]}\n{product[5]}\n{cnt}\nСтоимость:'
                                                        f'{product[4] / 100}0 ₽.', reply_markup=keyboard)


@dp.callback_query_handler(lambda c: 'cartadd' == c.data)
async def process_callback_bakery(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    await Count.count.set()
    await state.update_data(index_name=callback_query.message['text'].split('\n')[0])
    await callback_query.message.reply('Введите нужное количнство.')


@dp.message_handler(state=Count.count)
async def get_name(message: types.Message, state: FSMContext):
    await state.update_data(count=message.text)
    data = await state.get_data()
    await state.finish()
    a = f"SELECT * FROM products WHERE name='" + f"{data['index_name']}" + "';"
    product = cur.execute(a).fetchall()
    product = product[0]
    if product[3] >= int(data['count']) > 0:
        cart_count = f"SELECT * FROM cart WHERE user_id='" + f"{message.from_user.id}" + "';"
        try:
            cart_count = int(cur.execute(f"SELECT * FROM cart WHERE user_id='" + f"{message.from_user.id}" + "';").fetchall()[0][-1])
        except Exception:
            cart_count = 0
        if product[3] >= cart_count + int(data['count']):
            cur.execute('INSERT INTO cart VALUES(?, ?, ?);', [message.chat.id, product[1], int(data['count'])])
            conn.commit()
            await message.reply('Ваш заказ добавлен в корзину.', reply_markup=inline_kb_menu)
        else:
            await message.reply('Такого кол-ва нету.', reply_markup=inline_kb_menu)
    else:
        await message.reply('Такого кол-ва нету.', reply_markup=inline_kb_menu)


@dp.callback_query_handler(lambda c: 'cartadd' == c.data)
async def process_callback_bakery(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)


@dp.callback_query_handler(lambda c: c.data == 'review')
async def process_review(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await Review.star.set()
    await callback_query.message.reply('Сколько звёзд Вы поставите(от 0 до 10).')


@dp.message_handler(state=Review.star)
async def get_name(message: types.Message, state: FSMContext):
    await state.update_data(star=message.text)
    await message.answer("Теперь напишите отзыв.")
    await Review.next()


@dp.message_handler(state=Review.rev)
async def get_email(message: types.Message, state: FSMContext):
    await state.update_data(rev=message.text)
    data = await state.get_data()
    await state.finish()
    if (0 <= int(data['star']) <= 10):
        cur.execute("INSERT INTO review VALUES(?, ?, ?);", [message.from_user.id, int(data['star']), data['rev']])
        await message.reply('Отзыв принят.', reply_markup=inline_kb_menu)
    else:
        await message.reply('Некорректный отзыв.', reply_markup=inline_kb_menu)


@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message, state: FSMContext):
    data = await state.get_data()
    print(data)
    if data:
        await message.reply("Вас приветствует Бот-меню", reply_markup=inline_kb_menu)
    else:
        await message.reply("Вам нужно войти.")
        await Form.name.set()
        await message.reply('Введите ваше ФИО(через пробел).')


@dp.message_handler(state=Form.name)
async def get_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    await message.answer("Теперь введите класс обучения.")
    await Form.next()


@dp.message_handler(state=Form.cl)
async def get_cl(message: types.Message, state: FSMContext):
    await state.update_data(cl=message.text)
    await message.answer("Введите литеру вашего класса.")
    await Form.next()


@dp.message_handler(state=Form.liter)
async def get_liter(message: types.Message, state: FSMContext):
    await state.update_data(liter=message.text)
    await message.answer("Введите номер снилса.")
    await Form.next()


@dp.message_handler(state=Form.snils)
async def get_snils(message: types.Message, state: FSMContext):
    await state.update_data(snils=message.text)
    await message.answer("Введите свой email.")
    await Form.next()


@dp.message_handler(state=Form.email)
async def get_email(message: types.Message, state: FSMContext):
    await state.update_data(email=message.text)
    data = await state.get_data()
    await state.finish()
    cur.execute("SELECT * FROM users;")
    for i in cur.fetchall():
        if i[1] == data['name']:
            if i[2] == data['snils']:
                await message.answer('Вход, выполнен.\nВас приветствует Бот-меню', reply_markup=inline_kb_menu)
                break
    else:
        await message.answer("Неверный ввод.")


if __name__ == '__main__':
    executor.start_polling(dp)
