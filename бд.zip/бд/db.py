import sqlite3

conn = sqlite3.connect('dishes_menu.db')
cur = conn.cursor()
cur.execute('''CREATE TABLE products(
       id INT PRIMARY KEY,
       product_id INT,      
       name TEXT,       
       count INT,       
       price INT,       
       description TEXT,       
       picture TEXT,       
       category TEXT,       
       category_id INT    ); 
''')
conn.commit()
m = [(0, 0, 'Сок', 10, 6900, 'Апельсиновый сок.', 'сок.png', 'drinks', 1),
     (1, 1, 'Компот', 21, 4900, 'Компот из малины, собственного производства..', 'компот.png', 'drinks', 1),
     (2, 2, 'Морс', 8, 5900, 'Фирменный клюквенный морс.', 'морс.png', 'drinks', 1),
     (3, 3, 'Вода', 20, 3500, 'Питьевая вода негазированная, объёмом 0.5 литра.', 'вода.png', 'drinks', 1),
     (4, 4, 'Чай', 50, 2000, 'Тибетский черный чай.', 'чай.png', 'drinks', 1),
     (5, 5, 'Эчпочмак', 10, 7900, 'Традиционное татарское блюдо.', 'эчпочмак.png', 'bakery', 2),
     (6, 6, 'Борцоги', 35, 2500, 'Традиционное калмыцкое блюдо.', 'борцоги.png', 'bakery', 2),
     (7, 7, 'Мини-пицца', 47, 3900, 'ХИТ! мини-пицца собственного производства.', 'пицца.png', 'bakery', 2),
     (8, 8, 'Пирожок с капустой', 23, 3900, 'Приготовленное по-домашнему рецепту.', 'пирожок с капустой.png', 'bakery', 2),
     (9, 9, 'Сосиска в тесте', 9, 3900, 'Собственного производства', 'сосиска в тесте.png', 'bakery', 2),
     (10, 10, 'Беляш', 10, 5900, 'С сочной мясной начинкой.', 'беляш.jpg', 'bakery', 2),
     (11, 11, 'Кабартма', 32, 4500, 'Блюдо татарской кухни.', 'кабартма.jpg', 'bakery', 2),
     (12, 12, 'Пахлава', 24, 5000, 'Восточная сладость.', 'пахлава.jpg', 'bakery', 2),
     (13, 13, 'Чак-чак', 14, 3000, 'Мучное восточное печенье.', 'чак чак.jpg', 'bakery', 2),
     (14, 14, 'Кисель', 14, 3000, 'Со вскусом вишни.', 'кисель.jpg', 'drinks', 1),
     (15, 15, 'Калмыцкий чай', 14, 3000, 'Традиционный калмыцкий напиток.', 'калмыцкий чай.jpg', 'drinks', 1)
     ]
cur.executemany("INSERT INTO products VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?);", m)
conn.commit()


cur.execute("""CREATE TABLE users(    id INT PRIMARY KEY,    name TEXT,    cnils TEXT,    email TEXT,    role TEXT);""")
u = [(1, 'Буфет', '11122233344', 'buffet@mail.ru', 'admin'),     (2, '2', '2', '2', '2')]
cur.executemany("INSERT INTO users VALUES(?, ?, ?, ?, ?);", u)
conn.commit()


cur.execute('''CREATE TABLE cart (       
    user_id INT,       
    product_id INT,       
    count TEXT); 
''')
conn.commit()
cur.execute('''CREATE TABLE IF NOT EXISTS users (       
    id INT PRIMARY KEY,       
    user_id INT,       
    name TEXT,       
    role TEXT,       
    bought BOOLEAN NOT NULL DEFAULT (False),       
    label TEXT DEFAULT (1),       
    count INT); ''')
conn.commit()


cur.execute("""CREATE TABLE review(    
    id INT PRIMARY KEY,    
    text TEXT);""")
r = []
cur.executemany("INSERT INTO review VALUES(?, ?);", r)
conn.commit()


cur.execute(
    '''CREATE TABLE categories(         
    category_name TEXT,        
    category_id INT);''')
conn.commit()
m = [('drinks', 1), ('bakery', 2)]
cur.executemany('''INSERT INTO categories VALUES(?, ?)''', m)
conn.commit()
